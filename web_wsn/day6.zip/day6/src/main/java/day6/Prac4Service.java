package day6;


public class Prac4Service {

	
	public Book  getBookInfo() {
		Book book = new Book("뇌" ,"베르나르" ,9000);
		return book;
		
	}
}
