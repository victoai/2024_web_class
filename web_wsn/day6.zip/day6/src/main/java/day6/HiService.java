package day6;



public class HiService {
	
	//인사말 제공하는 매서드 
	public String  gethello() {
		String msg="hi servlet  ^^";
		return msg;
	}
}
