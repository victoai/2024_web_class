package prac1;


//서비스를 제공할 클래스 작성함
//기능은 매서드 단위로 작성
public class HapService { 
	
	public int hap( int su1, int su2) {		
		return su1+ su2;
	}
	  
}
