package day8;

import java.util.ArrayList;

public class SimpleService {

	//
	
	AcornDAO dao = new AcornDAO();
	
	public String getSimple() {
		String  str="이것이 MVC이다 ";
		return str;
	}
	
	

	
	
}
